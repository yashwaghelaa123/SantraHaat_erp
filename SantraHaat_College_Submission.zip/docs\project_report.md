# SantraHaat – Project Report
## E-Commerce and ERP | Academic Year 2024–25 | RTMNU, Nagpur

---

## 1. Introduction

**SantraHaat** (sahn-traa-haat, "Orange Market") is a B2C e-commerce web portal developed as a college project for the subject **E-Commerce and Enterprise Resource Planning (ERP)**. The platform is built around the cultural and agricultural heritage of the **Vidarbha region** of Maharashtra, India — most famously known for the **Nagpur Santra (orange)**, India's sweetest citrus fruit.

The platform enables customers to discover and purchase authentic local products — Nagpur oranges, regional spices and masalas, traditional Warli art and handicrafts, handloom textiles, and local snacks — all from the comfort of their home.

---

## 2. Purpose and Objectives

### Purpose
To create a fully functional demo e-commerce portal that:
- Showcases B2C e-commerce concepts learned in the curriculum.
- Promotes Vidarbha's local produce and artisan community.
- Serves as a template for potential real-world implementation.

### Objectives
1. Implement a complete customer shopping journey (browse → cart → checkout → order tracking).
2. Build an ERP-style admin back office for product, order, inventory and customer management.
3. Demonstrate e-commerce concepts: catalogue, cart, GST calculation, coupon discounts, simulated payment.
4. Apply form validation, localStorage-based persistence, and responsive design.
5. Provide a demo-ready, visually appealing portal for class presentation.

---

## 3. Scope

| In Scope | Out of Scope |
|---|---|
| Static HTML/CSS/JS frontend | Real backend server / database |
| localStorage data persistence | Real payment processing |
| 20 sample products across 5 categories | Mobile native app |
| Simulated UPI / Card / COD payment | Live shipping integration |
| Admin ERP dashboard with Chart.js | Email/SMS notifications |
| User registration, login, session | OAuth / social login |
| Order tracking (4 statuses) | Real-time inventory sync |
| Coupon management | Multi-vendor support |

---

## 4. Problem Statement

Small-scale farmers, weavers, and artisans of Vidarbha lack a dedicated digital marketplace to sell their products. Traditional channels involve multiple middlemen, reducing farmer income and increasing consumer prices. Additionally, authentic Vidarbha products are not easily discoverable outside the region.

**SantraHaat** addresses this gap by providing a direct-to-consumer online platform that connects Vidarbha producers with customers across India.

---

## 5. Technology Stack

| Layer | Technology | Rationale |
|---|---|---|
| Structure | HTML5 | Semantic, accessible markup |
| Styling | CSS3 (Vanilla) | Full control, no dependencies |
| Logic | JavaScript (ES6+) | No build step needed |
| Persistence | Browser localStorage | No backend required for demo |
| Charts | Chart.js (CDN) | Lightweight, beautiful charts |
| Fonts | Google Fonts (Poppins, Playfair Display) | Modern, professional typography |
| Icons | Unicode Emoji | No external icon library needed |

**Why no framework?** The project spec requires plain HTML/CSS/JS to run by simply opening index.html, making it accessible without any build tools or server.

---

## 6. Major Modules and Features

### 6.1 Customer Modules

| Module | Features |
|---|---|
| **Home Page** | Hero banner, category tiles, featured products, festival offer banners, testimonials, stats bar, newsletter |
| **Product Catalogue** | Grid view, search, category filter, price range filter, rating filter, stock filter, sorting (price/rating/newest), pagination, active filter tags |
| **Product Details** | Large image display, description, price with discount %, rating, stock status, quantity selector, Add to Cart, Wishlist toggle, related products, customer reviews |
| **Shopping Cart** | Item list, quantity update, remove items, subtotal, GST (5%), delivery charge (free above ₹499), coupon code application, grand total |
| **User Auth** | Email/password registration with validation, login, demo login, logout, session management via localStorage |
| **Checkout** | 3-step flow: Address → Payment → Confirmation; address form with validation; delivery option selection; simulated UPI/Card/COD payment gateway with loading screen; instant Tax Invoice view and print |
| **Tax Invoice & Billing** | GST-compliant tax invoice generation with CGST/SGST calculation, HSN code, customer and supplier GST details, print-optimized stylesheet |
| **My Account** | Order history with stepper tracker (Placed→Packed→Shipped→Delivered), invoice view, order cancellation and return requests, wishlist tab, profile edit |
| **Wishlist** | Dedicated wishlist page (`wishlist.html`), header navigation badge counter, toggle from cards & details, Add All to Cart |
| **Reviews** | Star rating input, review form (login required), display of reviews per product |

### 6.2 Admin (ERP) Modules

| Module | Features |
|---|---|
| **Admin Login** | Separate auth (admin/admin123), session guard on all admin pages |
| **Dashboard** | 4 KPI stat cards (Revenue, Orders, Customers, Low Stock); Chart.js line chart (7-day sales); doughnut chart (revenue by category); low-stock alerts; recent orders panel |
| **Product Management** | CRUD: Add/Edit/Delete products; search and category filter; featured/new toggle; emoji picker |
| **Order Management** | View all orders; inline status update dropdown; detailed order modal with address, items, and payment info |
| **Customer Management** | List of registered users with order count and total spend |
| **Inventory Report** | Stock overview with status indicators; quick stock update; low-stock highlight; out-of-stock list |
| **Coupon Management** | Add/Edit/Delete coupons; percentage and flat discount types; activate/deactivate toggle; minimum order requirement |

---

## 7. System Flow

### 7.1 Customer Journey

```mermaid
flowchart TD
    A([🏠 Home Page]) --> B[Browse Categories]
    B --> C[Product Listing / Search]
    C --> D[Product Detail Page]
    D --> E{Logged In?}
    E -->|No| F[Login / Register]
    F --> D
    E -->|Yes| G[Add to Cart / Wishlist]
    G --> H[Shopping Cart]
    H --> I[Apply Coupon]
    I --> J[Checkout Step 1: Address]
    J --> K[Checkout Step 2: Payment]
    K --> L{Payment Method}
    L -->|UPI| M[UPI Gateway Simulation]
    L -->|Card| N[Card Gateway Simulation]
    L -->|COD| O[Direct Order Placement]
    M --> P[Payment Processing Screen]
    N --> P
    P --> Q[Payment Success]
    Q --> R[Order Confirmation]
    O --> R
    R --> S[My Account: Track Order]
    S --> T[Order Status: Placed→Packed→Shipped→Delivered]
```

### 7.2 Payment Flow

```mermaid
sequenceDiagram
    participant C as Customer
    participant UI as SantraHaat UI
    participant LS as localStorage

    C->>UI: Clicks "Pay Now"
    UI->>UI: Show Payment Gateway Modal
    C->>UI: Enter UPI ID / Card Details
    UI->>UI: Simulate 2.5s Processing Delay
    UI->>UI: Show "Payment Successful" Screen
    UI->>LS: Store Order Object
    UI->>LS: Clear Cart
    UI->>LS: Deduct Stock
    UI->>C: Show Order Confirmation with Order ID
```

### 7.3 Admin Order Management Flow

```mermaid
flowchart LR
    A[Admin Login] --> B[Dashboard Overview]
    B --> C[Orders Page]
    C --> D{Select Order}
    D --> E[View Order Details]
    D --> F[Update Status: Placed→Packed→Shipped→Delivered]
    F --> G[localStorage Updated]
    G --> H[Customer sees updated status in My Account]
```

---

## 8. Data Flow Diagram (DFD)

### Level 0 – Context Diagram

```mermaid
flowchart LR
    C[👤 Customer] -->|Browse, Order, Review| SH[(SantraHaat System)]
    SH -->|Order Confirm, Tracking| C
    A[🔧 Admin] -->|Manage Products, Orders| SH
    SH -->|Reports, Alerts| A
```

### Level 1 – Detailed DFD

```mermaid
flowchart TD
    C([Customer]) -->|Search/Filter| P1[Product Catalogue]
    P1 -->|Product Data| DS[(localStorage Store)]
    DS -->|Products| P1
    C -->|Add Items| P2[Cart Management]
    P2 -->|Cart Data| DS
    C -->|Register/Login| P3[Authentication]
    P3 -->|User Session| DS
    C -->|Place Order| P4[Order Processing]
    P4 -->|Order Record| DS
    P4 -->|Coupon Validation| P5[Coupon Engine]
    P5 -->|Discount Amount| P4
    P4 -->|Stock Deduction| DS

    A([Admin]) -->|CRUD| P6[Product Management]
    P6 -->|Update Products| DS
    A -->|Status Update| P7[Order Management]
    P7 -->|Update Orders| DS
    DS -->|All Orders/Customers| P8[Dashboard/Reports]
    P8 -->|KPIs, Charts| A
```

---

## 9. ER Diagram

```mermaid
erDiagram
    USER {
        string email PK
        string name
        string phone
        string password
        datetime joinedAt
    }
    PRODUCT {
        string id PK
        string name
        string category
        string description
        float price
        float originalPrice
        int stock
        float rating
        int reviews
        bool isFeatured
        bool isNew
        string emoji
        array tags
    }
    ORDER {
        string id PK
        string userId FK
        string status
        float subtotal
        float gst
        float deliveryCharge
        float discount
        float total
        string payMethod
        string coupon
        datetime placedAt
        json address
    }
    ORDER_ITEM {
        string orderId FK
        string productId FK
        string name
        float price
        int qty
    }
    REVIEW {
        string productId FK
        string author
        int rating
        string title
        string body
        datetime date
    }
    COUPON {
        string code PK
        float discount
        string type
        float minOrder
        string description
        bool active
    }
    WISHLIST {
        string userId FK
        string productId FK
    }

    USER ||--o{ ORDER : "places"
    ORDER ||--|{ ORDER_ITEM : "contains"
    PRODUCT ||--o{ ORDER_ITEM : "included in"
    PRODUCT ||--o{ REVIEW : "has"
    USER ||--o{ REVIEW : "writes"
    USER ||--o{ WISHLIST : "saves"
    PRODUCT ||--o{ WISHLIST : "saved in"
    ORDER ||--o| COUPON : "uses"
```

---

## 10. Use-Case List

| # | Actor | Use Case |
|---|---|---|
| UC01 | Customer | Browse products by category |
| UC02 | Customer | Search products by name/keyword |
| UC03 | Customer | Filter products by price, rating, availability |
| UC04 | Customer | View product details, images and reviews |
| UC05 | Customer | Register a new account |
| UC06 | Customer | Login to existing account |
| UC07 | Customer | Add product to shopping cart |
| UC08 | Customer | Update cart (change qty / remove item) |
| UC09 | Customer | Apply coupon code to order |
| UC10 | Customer | Proceed to checkout with address form |
| UC11 | Customer | Select delivery option (Standard / Express) |
| UC12 | Customer | Simulate payment (UPI / Card / COD) |
| UC13 | Customer | View order confirmation with Order ID |
| UC14 | Customer | Track order status in My Account |
| UC15 | Customer | Add product to wishlist |
| UC16 | Customer | Write product review with star rating |
| UC17 | Customer | Edit profile information |
| UC18 | Admin | Login to Admin ERP Panel |
| UC19 | Admin | View dashboard KPIs and sales charts |
| UC20 | Admin | Add / Edit / Delete products |
| UC21 | Admin | Update product stock |
| UC22 | Admin | View all orders and customer details |
| UC23 | Admin | Update order delivery status |
| UC24 | Admin | View inventory with low-stock alerts |
| UC25 | Admin | Add / Edit / Delete coupon codes |
| UC26 | Admin | View registered customer list |
| UC27 | Admin | Logout from admin panel |

---

## 11. Portal Screenshots & Visual Tour

This section illustrates the visual execution, responsive design, and user experience across all key pages and ERP back-office modules of SantraHaat.

### 11.1 Customer Portal Screenshots

#### Figure 1: Home Page & Hero Section
The landing page greets users with the Vidarbha Mango Cream & Santra Orange hero gradient, animated floating orange icon ring, statistics bar, category tiles, and festival promotional banners.
![Home Page](screenshots/01_homepage.png)

#### Figure 2: Product Catalogue (Shop Page)
The shop interface provides faceted search, live price slider (₹0–₹3000), category filters (Oranges, Spices, Snacks, Handloom, Handicrafts), rating filters, stock toggles, multi-criteria sorting, and responsive pagination.
![Shop Catalogue](screenshots/02_shop_catalogue.png)

#### Figure 3: Product Detail View
Detailed single-product view showcasing category badge, dynamic rating calculation, stock availability indicator, quantity selector, customer review list, related products grid, and interactive review submission modal.
![Product Detail](screenshots/03_product_detail.png)

#### Figure 4: Shopping Cart & Price Breakdown
Comprehensive cart breakdown showing item thumbnails, quantity modifiers, automated 5% GST computation, dynamic delivery threshold (Free delivery on orders above ₹499), and live coupon application engine (`SANTRA10`).
![Shopping Cart](screenshots/04_shopping_cart.png)

#### Figure 5: Multi-Step Checkout Flow
Standard 3-step checkout: Address validation with PIN code checker, delivery tier selector (Standard vs Express) with live real-time summary recalculation, and simulated payment methods (UPI, Card, COD).
![Checkout Flow](screenshots/05_checkout_step.png)

#### Figure 6: User Account & Order Status Stepper
Customer dashboard displaying user avatar, profile editing, and detailed order history featuring an interactive visual stepper (`Placed` → `Packed` → `Shipped` → `Delivered`), order cancellation, return requests, and Tax Invoice viewing.
![User Account](screenshots/06_user_account.png)

#### Figure 7: Dedicated Wishlist Page
Curated customer wishlist featuring saved regional handicrafts and snacks, live prices, "Add All to Cart" one-click action, and individual remove toggles.
![Wishlist Page](screenshots/07_wishlist.png)

#### Figure 8: Authentication & Registration Portal
Dual tabbed authentication portal with real-time field validation, password confirmation matching, terms acceptance, and one-click demo login.
![Login and Registration](screenshots/08_login_register.png)

---

### 11.2 Admin ERP Back-Office Screenshots

#### Figure 9: Admin ERP Dashboard
Unified executive dashboard showing 4 real-time KPI stat cards (Total Revenue, Total Orders, Registered Customers, Low Stock Alerts), interactive Chart.js revenue trend graphs, low-stock warnings, and recent order stream.
![Admin Dashboard](screenshots/09_admin_dashboard.png)

#### Figure 10: Product Catalogue Management (CRUD)
ERP inventory controller allowing the store administrator to view all products, search, filter by category, add new products, edit pricing and stock levels, and toggle featured/new badges.
![Admin Product Management](screenshots/10_admin_products.png)

#### Figure 11: Order Processing & Status Pipeline
Central order fulfillment console providing instant status dropdown modification (`Placed` → `Packed` → `Shipped` → `Delivered`), search by Customer/Order ID, detailed modal inspection, and printable Tax Invoices.
![Admin Order Management](screenshots/11_admin_orders.png)

#### Figure 12: Inventory & Restocking Report
Inventory surveillance table featuring color-coded stock health badges (Well Stocked, Low Stock, Out of Stock), stock alert banners, quick inline quantity restockers, and printable inventory reports.
![Admin Inventory Report](screenshots/12_admin_inventory.png)

#### Figure 13: Discount Coupon Engine
Promotional discount manager allowing creation of percentage-based and flat-rate coupons, setting minimum order requirements, and instant activation/deactivation.
![Admin Coupon Management](screenshots/13_admin_coupons.png)

---

## 12. E-Commerce Type and Business Model

### Type
**B2C – Business to Consumer**

SantraHaat operates on a B2C model where the platform (business) sells products directly to individual consumers. This is similar to platforms like Amazon, Flipkart and BigBasket, but focused exclusively on Vidarbha's local produce.

### Business Model
- **Direct Sales**: Products listed are sold directly by the platform.
- **Category-based Pricing**: Products priced based on category and quality (no auction/bidding).
- **Commission Model (future)**: In a real deployment, local sellers/artisans would list products and SantraHaat would charge a commission per sale.
- **Coupon-based Marketing**: Discount coupons (SANTRA10, DIWALI20, etc.) drive customer acquisition.
- **Free Delivery Incentive**: Free delivery on orders above ₹499 encourages higher cart value.

---

## 13. Security Considerations

| Security Aspect | Implementation in Demo | Real-World Requirement |
|---|---|---|
| **Authentication** | Email + password match in localStorage | Hashed passwords (bcrypt), JWT tokens |
| **Session Management** | localStorage session object | HTTP-only cookies, secure session tokens |
| **Data Transmission** | N/A (frontend only) | HTTPS/TLS encryption required |
| **Input Validation** | Client-side JS validation | Server-side validation + sanitization |
| **SQL Injection** | N/A (no database) | Parameterized queries / ORM |
| **XSS Prevention** | innerHTML used carefully | Content Security Policy, sanitization library |
| **Payment Security** | Simulated only | PCI DSS compliant payment gateway (Razorpay, PayU) |
| **Admin Access** | Hardcoded admin/admin123 | Role-based access control (RBAC) |
| **CSRF Protection** | N/A (no server) | CSRF tokens on all state-changing requests |

---

## 14. Advantages

1. **No Build Step Required** – Runs directly from the browser, no server needed.
2. **Fully Functional Demo** – Complete shopping flow from browse to order confirmation.
3. **Data Persistence** – localStorage ensures data survives page refreshes.
4. **ERP Integration Demonstrated** – Admin dashboard shows how e-commerce and ERP connect.
5. **Responsive Design** – Works on mobile, tablet, and desktop.
6. **Rich UI** – Modern design with animations, gradients, and micro-interactions.
7. **Educational Value** – Well-commented code easy for students to understand.
8. **Realistic Data** – 20 authentic Vidarbha products with real pricing.

---

## 15. Limitations

1. **No Real Backend** – Data is not shared across devices or browsers.
2. **No Real Payment** – Payment is simulated; no actual money transfers.
3. **No Email Notifications** – Order confirmation cannot be emailed.
4. **localStorage Limits** – ~5–10 MB storage limit per browser.
5. **Single User Context** – No true multi-user concurrency.
6. **No Image CDN** – Product images are represented by emoji.
7. **Security** – Passwords stored in plain text (educational demo only).
8. **No Search Engine Indexing** – Static pages without a server cannot be indexed properly.

---

## 16. Future Enhancements

| Enhancement | Description |
|---|---|
| **Real Backend** | Node.js + Express + MongoDB or Firebase for persistent, shared data |
| **Real Payment Gateway** | Integrate Razorpay or PayU for actual UPI/card transactions |
| **AI Recommendations** | Machine learning model to suggest products based on purchase history |
| **Mobile App** | React Native or Flutter app for iOS/Android |
| **WhatsApp Integration** | Order notifications via WhatsApp Business API |
| **Vendor Portal** | Allow Vidarbha farmers/artisans to list their own products |
| **Advanced Analytics** | Google Analytics, Mixpanel for user behaviour tracking |
| **Multi-Language** | Support for Marathi (मराठी) language for rural users |
| **Loyalty Program** | SantraPoints reward system for repeat purchases |
| **Live Inventory Sync** | Real-time stock updates when multiple customers are shopping |

---

## 17. Conclusion

SantraHaat successfully demonstrates a complete B2C e-commerce ecosystem using only front-end technologies (HTML, CSS, JavaScript, localStorage). The platform covers all key e-commerce concepts studied in the E-Commerce and ERP course — product catalogue, shopping cart, checkout, order management, payment simulation, GST calculation, coupon discounts, and an ERP-style admin dashboard.

Beyond the academic scope, the project has real-world inspiration and relevance. Vidarbha's Nagpur oranges, Warli art, and local spices are products with significant market potential, and a platform like SantraHaat could genuinely empower local farmers and artisans by connecting them directly to consumers across India.

The project meets all the specified requirements and is demo-ready for classroom presentation.

---

*Project: SantraHaat – Vidarbha's Local Bazaar, Online*
*Subject: E-Commerce and ERP | RTMNU, Nagpur | 2024–25*