# SantraHaat – Class Demo Script
## Step-by-Step Presentation Guide

---

## Pre-Demo Setup

1. Open `index.html` in a modern browser (Chrome / Edge recommended)
2. Clear localStorage: Open DevTools (F12) → Application → Local Storage → Clear All
3. Keep the browser window at 100% zoom
4. Have a second tab ready for the admin panel: `admin/login.html`

---

## Demo Script (15–20 minutes)

### PART 1: Customer Experience (10 min)

**Step 1 – Home Page** *(2 min)*
- Show the hero banner with orange gradient
- Point out the category tiles (5 categories)
- Scroll to Featured Products section
- Point out Festival Offer banners (SANTRA10, DIWALI20 coupons)
- Show testimonials and newsletter

> 💬 Say: *"This is a B2C e-commerce portal. The homepage follows e-commerce best practices — hero section, category navigation, featured products, and promotional banners."*

**Step 2 – Product Catalogue** *(2 min)*
- Click "Shop" in header
- Apply a category filter (e.g., "Oranges")
- Use the price range slider
- Sort by "Best Rating"
- Use the search bar to search "masala"
- Show the active filter tags and results count

> 💬 Say: *"The catalogue has search, filter and sort — standard features of any e-commerce platform."*

**Step 3 – Product Details** *(1 min)*
- Click on "Nagpur Santra Premium Box"
- Show the product image, description, rating, stock status
- Change quantity to 2
- Click "Add to Cart"
- Show the toast notification and cart badge updating

**Step 4 – User Registration** *(1 min)*
- Click the cart icon → Cart is visible with items
- Click "Proceed to Checkout" → Redirected to login
- Go to Login page → Click "Register"
- Register with: Name: Yash Sharma, Email: yash@test.com, Phone: 9876543210, Password: test123
- Show "Welcome!" toast and redirect to account

**Step 5 – Cart & Checkout** *(3 min)*
- Navigate to Cart
- Show: Item, Qty, Price, GST (5%), Delivery charge
- Apply coupon code: `SANTRA10` → Show discount applied
- Click "Proceed to Checkout"
- Fill address form → show form validation (submit empty to trigger errors)
- Fill correct address → click "Continue to Payment"
- Select "UPI Payment"
- Enter fake UPI ID: `demo@upi`
- Click "Pay Now" → Show loading animation (2.5 sec)
- Show "Payment Successful!" screen
- Show Order Confirmation with Order ID
- Click "📄 View & Print Invoice" → Show full GST Tax Invoice modal with itemized breakdown and print functionality

**Step 6 – My Account, Wishlist & Order Tracking** *(1.5 min)*
- Navigate to My Account
- Show order history with order stepper (Placed status)
- Click "📄 View Invoice" to show the persistent invoice
- Point out order action buttons (Cancel Order / Return Request)
- Click "❤️ Wishlist" in header navigation → View dedicated Wishlist page
- Click "🛒 Add All to Cart" from Wishlist
- Show Profile tab with editable profile information

---

### PART 2: Admin ERP Panel (7 min)

**Step 7 – Admin Login** *(30 sec)*
- Open `admin/login.html`
- Login with: `admin` / `admin123`

> 💬 Say: *"The admin panel is the ERP (Enterprise Resource Planning) back office. It gives the business owner complete control over operations."*

**Step 8 – Dashboard** *(2 min)*
- Show KPI cards: Revenue, Orders, Customers, Low Stock
- Show Line Chart (7-day sales trend)
- Show Doughnut Chart (revenue by category)
- Point out low-stock alert list
- Show recent orders panel

**Step 9 – Product Management** *(1.5 min)*
- Click "Products" in sidebar
- Show all 20 products in the table
- Click "+ Add Product"
- Fill in: Name, Category (Oranges), Price (399), Stock (50), Emoji (🍊)
- Save → Show new product in table
- Edit a product (change stock) → Save
- Show delete functionality (but cancel)

**Step 10 – Order Management** *(1.5 min)*
- Click "Orders" in sidebar
- Find the order just placed by demo customer
- Click the Status dropdown → Change from "Placed" to "Packed"
- Show toast confirmation
- Click "View" → Show full order details modal

> 💬 Say: *"This is the ERP component — the admin can update order status and the customer's tracking page will automatically reflect this change."*

**Step 11 – Inventory Report** *(1 min)*
- Click "Inventory" in sidebar
- Show green/yellow/red stock indicators
- Show low-stock warning banner
- Quick-update one product's stock → Show update

**Step 12 – Coupons** *(30 sec)*
- Show existing coupons: SANTRA10, FIRST50, VIDARBHA, DIWALI20
- Add a new coupon: DEMO15 (15% off)

---

### PART 3: Technical Concepts Summary *(2 min)*

Point out these concepts implemented:

| Concept | Where in Project |
|---|---|
| B2C Model | Customer buys directly from platform |
| Product Catalogue | Shop page with filters |
| Shopping Cart | Cart page with qty management |
| GST Calculation | 5% GST shown in cart and checkout |
| Coupon/Discount | Cart and checkout coupon input |
| Payment Gateway | Simulated UPI and Card gateway |
| Order Management | My Account + Admin orders |
| ERP Dashboard | Admin dashboard with charts |
| Inventory Management | Admin inventory page |
| Form Validation | All forms have client-side validation |
| Session Management | Login/logout with localStorage |

---

## Key Questions to Prepare For

**Q: Why localStorage instead of a database?**
> A: For a client-side demo without a backend, localStorage provides sufficient persistence. A real deployment would use a Node.js backend with MongoDB or MySQL.

**Q: Is the payment secure?**
> A: This is a simulated payment. In real deployment, we would integrate Razorpay or PayU — PCI DSS compliant gateways — over HTTPS.

**Q: What type of e-commerce is this?**
> A: B2C (Business to Consumer), where SantraHaat acts as the business selling products directly to individual consumers.

**Q: What does ERP stand for and where is it used here?**
> A: Enterprise Resource Planning — it integrates all business functions. The admin panel demonstrates ERP by managing products, orders, inventory and customers in one unified system.

---

*SantraHaat – Vidarbha's Local Bazaar, Online*
*E-Commerce & ERP Project | RTMNU Nagpur | 2024–25*