/* Admin shared JS – sidebar and auth guard */

// ── Admin Auth Guard ───────────────────────────────────────────
function adminGuard() {
  if (new URLSearchParams(window.location.search).get('demo') === '1') {
    sessionStorage.setItem('sh_admin', 'true');
  }
  if (!sessionStorage.getItem('sh_admin')) {
    window.location.href = 'login.html';
    return false;
  }
  return true;
}

// ── Build Admin Sidebar ────────────────────────────────────────
function buildAdminSidebar(activePage) {
  const sidebar = document.getElementById('admin-sidebar');
  if (!sidebar) return;
  const pages = [
    { id:'dashboard',  icon:'📊', label:'Dashboard',       href:'dashboard.html' },
    { id:'products',   icon:'🛍️', label:'Products',         href:'products.html' },
    { id:'orders',     icon:'📦', label:'Orders',           href:'orders.html' },
    { id:'customers',  icon:'👥', label:'Customers',        href:'customers.html' },
    { id:'inventory',  icon:'📋', label:'Inventory',        href:'inventory.html' },
    { id:'coupons',    icon:'🏷️', label:'Coupons',          href:'coupons.html' },
  ];
  sidebar.innerHTML = `
    <div class="brand">🍊 SantraHaat</div>
    <div class="sub">Admin ERP Panel</div>
    <nav class="admin-nav">
      ${pages.map(p => `<a href="${p.href}" class="${activePage===p.id?'active':''}">${p.icon} ${p.label}</a>`).join('')}
      <div class="section-label">System</div>
      <a href="../index.html">🏪 View Store</a>
      <a href="#" onclick="adminLogout()" style="color:rgba(255,100,100,0.9)">🚪 Logout</a>
    </nav>`;
}

function adminLogout() {
  sessionStorage.removeItem('sh_admin');
  window.location.href = 'login.html';
}

// ── Format price & date helpers ───────────────────────────────
function fmtP(n) { return '₹' + Number(n).toLocaleString('en-IN'); }
if (typeof fmtDate === 'undefined') {
  window.fmtDate = function(d) { return new Date(d).toLocaleDateString('en-IN', { day:'numeric', month:'short', year:'numeric' }); };
}