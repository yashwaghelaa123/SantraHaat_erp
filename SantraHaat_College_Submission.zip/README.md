# 🍊 SantraHaat – Vidarbha's Local Bazaar, Online
## Academic Project: E-Commerce & ERP | RTMNU Nagpur | 2024–25

**SantraHaat** is a B2C e-commerce web portal built with Vanilla HTML5, CSS3, and JavaScript (ES6+), integrating an ERP back-office back-end simulation using browser `localStorage`.

---

## 🚀 How to Run

1. **Option A (Instant Direct Open):**
   - Double-click or open `index.html` in any modern web browser (Google Chrome, Microsoft Edge, Mozilla Firefox).
   - No build tools, NodeJS, or external servers are required.

2. **Option B (Local Web Server):**
   - Open PowerShell or Terminal in the project root directory:
     ```bash
     python -m http.server 3000
     ```
   - Visit: `http://localhost:3000`

---

## 🔑 Demo Credentials

- **Customer Store:** Click the **"Demo Login"** button on `pages/login.html` (or use `demo@santrahaat.com` / `demo123`).
- **Admin ERP Panel:** Access at `admin/login.html` with:
  - Username: **`admin`**
  - Password: **`admin123`**

---

## 📁 Project Architecture & Submission Files

- `docs/SantraHaat_Project_Report.pdf`: Compiled academic project report with embedded screenshots.
- `docs/project_report.html`: Interactive HTML report with print-to-PDF formatting.
- `docs/project_report.md`: Complete markdown documentation.
- `docs/screenshots/`: High-resolution screenshots of all 13 customer and admin portal views.
- `docs/demo_script.md`: Step-by-step 15-minute presentation guide.
- `index.html`: Portal homepage with hero section, category tiles, featured products, and newsletter.
- `pages/`: Customer interfaces (`shop.html`, `product.html`, `cart.html`, `checkout.html`, `account.html`, `wishlist.html`, `login.html`, `about.html`, `contact.html`, `privacy.html`, `returns.html`).
- `admin/`: ERP back-office modules (`dashboard.html`, `products.html`, `orders.html`, `customers.html`, `inventory.html`, `coupons.html`).
- `css/style.css`: Unified design system, responsive styles, and `@media print` tax invoice & report styles.
- `js/app.js`: Central state management, cart totals, GST tax calculator, coupon engine, and dynamic tax invoice builder.
