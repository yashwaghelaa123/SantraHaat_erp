/* ============================================================
   SantraHaat – Shared Utilities & Data Store (app.js)
   All localStorage operations and helper functions live here.
   ============================================================ */

// ── Constants ─────────────────────────────────────────────────
const KEYS = {
  PRODUCTS:  'sh_products',
  USERS:     'sh_users',
  CART:      'sh_cart',
  ORDERS:    'sh_orders',
  WISHLIST:  'sh_wishlist',
  SESSION:   'sh_session',
  REVIEWS:   'sh_reviews',
  COUPONS:   'sh_coupons',
};

// ── Sample Products (20 across 5 categories) ──────────────────
const SAMPLE_PRODUCTS = [
  // ── Oranges & Orange Products ──────────────────────────────
  {
    id: 'P001', name: 'Nagpur Santra Premium Box (5 kg)',
    category: 'Oranges', price: 349, originalPrice: 450,
    emoji: '🍊', description: 'Fresh, juicy Nagpur Santra oranges handpicked from Vidarbha orchards. Known for their thin skin, seedless pulp and unmatched sweetness.',
    rating: 4.7, reviews: 142, stock: 85, isNew: false, isFeatured: true,
    tags: ['fresh', 'seasonal', 'organic']
  },
  {
    id: 'P002', name: 'Nagpur Orange Marmalade (250 g)',
    category: 'Oranges', price: 149, originalPrice: 180,
    emoji: '🍯', description: 'Handmade orange marmalade prepared from fresh Nagpur oranges with no artificial preservatives. Great with toast or as a dessert topping.',
    rating: 4.5, reviews: 78, stock: 40, isNew: false, isFeatured: true,
    tags: ['homemade', 'preserve']
  },
  {
    id: 'P003', name: 'Santra Cold-Pressed Juice (1 L)',
    category: 'Oranges', price: 199, originalPrice: 240,
    emoji: '🥤', description: 'Cold-pressed fresh Nagpur orange juice. No sugar added, no preservatives. 100% pure goodness from Vidarbha farms.',
    rating: 4.6, reviews: 93, stock: 30, isNew: true, isFeatured: false,
    tags: ['fresh', 'no-sugar', 'healthy']
  },
  {
    id: 'P004', name: 'Orange Blossom Honey (500 g)',
    category: 'Oranges', price: 499, originalPrice: 599,
    emoji: '🍯', description: 'Wild honey harvested from orange orchards of Vidarbha. Delicate floral aroma with natural sweetness. 100% pure & raw.',
    rating: 4.8, reviews: 67, stock: 18, isNew: false, isFeatured: true,
    tags: ['organic', 'honey', 'natural']
  },
  // ── Handloom & Warli Art ───────────────────────────────────
  {
    id: 'P005', name: 'Warli Art Wall Hanging (18"×24")',
    category: 'Handicrafts', price: 899, originalPrice: 1200,
    emoji: '🎨', description: 'Traditional Warli tribal art painted on handmade canvas. Depicts village life, nature and festivals. Each piece is unique and handcrafted by Vidarbha artisans.',
    rating: 4.9, reviews: 54, stock: 12, isNew: false, isFeatured: true,
    tags: ['art', 'tribal', 'handmade']
  },
  {
    id: 'P006', name: 'Paithani Silk Stole (Vidarbha Weave)',
    category: 'Handloom', price: 2499, originalPrice: 3200,
    emoji: '🧣', description: 'Authentic Paithani-weave silk stole from Vidarbha handloom weavers. Rich peacock motifs with zari border. A collector\'s piece of wearable heritage.',
    rating: 4.8, reviews: 32, stock: 8, isNew: false, isFeatured: true,
    tags: ['silk', 'handloom', 'heritage']
  },
  {
    id: 'P007', name: 'Warli Printed Cotton Kurta (Unisex)',
    category: 'Handloom', price: 799, originalPrice: 999,
    emoji: '👘', description: 'Comfortable cotton kurta with Warli tribal prints. Proudly made by cooperative weavers of Nagpur district. Breathable and eco-friendly fabric.',
    rating: 4.4, reviews: 45, stock: 22, isNew: true, isFeatured: false,
    tags: ['cotton', 'kurta', 'warli']
  },
  {
    id: 'P008', name: 'Warli Art Notebook Set (3 pcs)',
    category: 'Handicrafts', price: 349, originalPrice: 429,
    emoji: '📓', description: 'Set of 3 handmade paper notebooks with Warli art covers. Ideal for journaling, gifting or as a corporate souvenir promoting local art.',
    rating: 4.5, reviews: 61, stock: 35, isNew: false, isFeatured: false,
    tags: ['stationery', 'gift', 'warli']
  },
  // ── Spices ────────────────────────────────────────────────
  {
    id: 'P009', name: 'Vidarbha Red Chilli Powder (200 g)',
    category: 'Spices', price: 119, originalPrice: 150,
    emoji: '🌶️', description: 'Sun-dried red chilli powder from Vidarbha farms. Vibrant red colour, moderate heat and earthy aroma. Essential for authentic Maharashtrian cooking.',
    rating: 4.6, reviews: 188, stock: 60, isNew: false, isFeatured: false,
    tags: ['spicy', 'authentic', 'maharashtrian']
  },
  {
    id: 'P010', name: 'Garam Masala Blend – Vidarbha Style (100 g)',
    category: 'Spices', price: 189, originalPrice: 229,
    emoji: '🫙', description: 'Stone-ground garam masala with 14 traditional spices. Special Vidarbha recipe passed down through generations of local spice traders.',
    rating: 4.7, reviews: 104, stock: 45, isNew: false, isFeatured: true,
    tags: ['masala', 'blend', 'traditional']
  },
  {
    id: 'P011', name: 'Organic Turmeric Powder (200 g)',
    category: 'Spices', price: 149, originalPrice: 180,
    emoji: '🟡', description: 'High-curcumin organic turmeric from Vidarbha farms. Deep golden colour, high medicinal value. Certified organic by local farmer cooperative.',
    rating: 4.8, reviews: 76, stock: 55, isNew: false, isFeatured: false,
    tags: ['organic', 'turmeric', 'healthy']
  },
  {
    id: 'P012', name: 'Kalahari Sesame (Til) Seeds – 500 g',
    category: 'Spices', price: 139, originalPrice: 165,
    emoji: '🫘', description: 'Premium white sesame seeds from Vidarbha. Perfect for til ladoos, chutneys and festive preparations. Freshly packed, naturally oil-rich.',
    rating: 4.3, reviews: 57, stock: 70, isNew: false, isFeatured: false,
    tags: ['sesame', 'festival', 'til']
  },
  // ── Snacks ────────────────────────────────────────────────
  {
    id: 'P013', name: 'Saoji Mutton Masala Biscuits (200 g)',
    category: 'Snacks', price: 99, originalPrice: 120,
    emoji: '🍪', description: 'Crispy biscuits flavoured with famous Nagpur Saoji spice blend. An innovative local snack that captures the bold flavours of Vidarbha\'s signature cuisine.',
    rating: 4.4, reviews: 132, stock: 50, isNew: true, isFeatured: true,
    tags: ['saoji', 'crispy', 'local-flavour']
  },
  {
    id: 'P014', name: 'Halwa Puri Mix – Nagpur Style (500 g)',
    category: 'Snacks', price: 179, originalPrice: 210,
    emoji: '🫓', description: 'Ready-mix for making traditional Nagpur-style halwa puri at home. Made with semolina, pure ghee and aromatic cardamom. Quick festive treat.',
    rating: 4.2, reviews: 48, stock: 28, isNew: false, isFeatured: false,
    tags: ['traditional', 'dessert', 'mix']
  },
  {
    id: 'P015', name: 'Bhajani Chakli Mix (400 g)',
    category: 'Snacks', price: 159, originalPrice: 190,
    emoji: '🌀', description: 'Traditional Maharashtrian chakli mix made with multiflour blend (bhajani). Prepare crispy, golden chaklis effortlessly at home. Popular Diwali snack.',
    rating: 4.6, reviews: 87, stock: 40, isNew: false, isFeatured: true,
    tags: ['chakli', 'diwali', 'traditional']
  },
  {
    id: 'P016', name: 'Dry Fruit Laddoo Box (12 pcs)',
    category: 'Snacks', price: 449, originalPrice: 549,
    emoji: '🟤', description: 'Handmade laddoos loaded with dry fruits, jaggery and Vidarbha sesame. No refined sugar, no preservatives. An ideal festive gift box.',
    rating: 4.8, reviews: 65, stock: 20, isNew: false, isFeatured: true,
    tags: ['laddoo', 'gift', 'no-sugar']
  },
  // ── Handicrafts ───────────────────────────────────────────
  {
    id: 'P017', name: 'Bamboo Pen Stand with Warli Art',
    category: 'Handicrafts', price: 299, originalPrice: 399,
    emoji: '🪵', description: 'Eco-friendly bamboo pen stand decorated with hand-painted Warli art. Makes a great desk accessory and a meaningful corporate gift promoting local artisans.',
    rating: 4.6, reviews: 43, stock: 25, isNew: false, isFeatured: false,
    tags: ['bamboo', 'eco', 'desk']
  },
  {
    id: 'P018', name: 'Terracotta Orange Planter Set (3 pcs)',
    category: 'Handicrafts', price: 649, originalPrice: 849,
    emoji: '🪴', description: 'Hand-thrown terracotta planters with traditional Nagpur motifs. Each pot is unique, made by potters of Ramtek district. Ideal for succulents and herbs.',
    rating: 4.7, reviews: 38, stock: 14, isNew: true, isFeatured: false,
    tags: ['terracotta', 'planter', 'handmade']
  },
  {
    id: 'P019', name: 'Jute Tote Bag with Warli Print',
    category: 'Handicrafts', price: 249, originalPrice: 329,
    emoji: '👜', description: 'Natural jute tote bag with screen-printed Warli tribal art. Sturdy, eco-friendly and stylish. Promotes sustainable living while celebrating tribal heritage.',
    rating: 4.5, reviews: 71, stock: 48, isNew: false, isFeatured: false,
    tags: ['jute', 'eco', 'bag']
  },
  {
    id: 'P020', name: 'Coconut Shell Diyas Set (6 pcs)',
    category: 'Handicrafts', price: 199, originalPrice: 269,
    emoji: '🪔', description: 'Hand-crafted oil diyas made from coconut shells, decorated with Warli patterns. Beautiful and eco-friendly alternative to plastic diyas. Perfect for Diwali.',
    rating: 4.4, reviews: 55, stock: 60, isNew: false, isFeatured: true,
    tags: ['diya', 'diwali', 'coconut']
  }
];

// ── Default Coupons ────────────────────────────────────────────
const DEFAULT_COUPONS = [
  { code: 'SANTRA10', discount: 10, type: 'percent', minOrder: 0,   active: true, description: '10% off on all orders' },
  { code: 'FIRST50',  discount: 50, type: 'flat',    minOrder: 299, active: true, description: 'Flat ₹50 off on first order' },
  { code: 'VIDARBHA', discount: 15, type: 'percent', minOrder: 499, active: true, description: '15% off on orders above ₹499' },
  { code: 'DIWALI20', discount: 20, type: 'percent', minOrder: 999, active: true, description: '20% off – Diwali Special!' },
];

// ── Initialize localStorage with defaults ─────────────────────
function initStore() {
  if (!localStorage.getItem(KEYS.PRODUCTS)) {
    localStorage.setItem(KEYS.PRODUCTS, JSON.stringify(SAMPLE_PRODUCTS));
  }
  if (!localStorage.getItem(KEYS.USERS)) {
    // Seed one admin user (handled by admin login separately)
    localStorage.setItem(KEYS.USERS, JSON.stringify([]));
  }
  if (!localStorage.getItem(KEYS.CART)) {
    localStorage.setItem(KEYS.CART, JSON.stringify([]));
  }
  if (!localStorage.getItem(KEYS.ORDERS)) {
    localStorage.setItem(KEYS.ORDERS, JSON.stringify([]));
  }
  if (!localStorage.getItem(KEYS.WISHLIST)) {
    localStorage.setItem(KEYS.WISHLIST, JSON.stringify([]));
  }
  if (!localStorage.getItem(KEYS.REVIEWS)) {
    localStorage.setItem(KEYS.REVIEWS, JSON.stringify({}));
  }
  if (!localStorage.getItem(KEYS.COUPONS)) {
    localStorage.setItem(KEYS.COUPONS, JSON.stringify(DEFAULT_COUPONS));
  }
}

// ── Store CRUD Helpers ─────────────────────────────────────────
const Store = {
  get: (key) => JSON.parse(localStorage.getItem(key) || '[]'),
  getObj: (key) => JSON.parse(localStorage.getItem(key) || '{}'),
  set: (key, val) => localStorage.setItem(key, JSON.stringify(val)),

  // Products
  getProducts: () => Store.get(KEYS.PRODUCTS),
  setProducts: (p) => Store.set(KEYS.PRODUCTS, p),
  getProduct: (id) => Store.getProducts().find(p => p.id === id),
  addProduct: (p) => { const arr = Store.getProducts(); arr.push(p); Store.setProducts(arr); },
  updateProduct: (id, data) => {
    const arr = Store.getProducts();
    const i = arr.findIndex(p => p.id === id);
    if (i !== -1) { arr[i] = { ...arr[i], ...data }; Store.setProducts(arr); }
  },
  deleteProduct: (id) => Store.setProducts(Store.getProducts().filter(p => p.id !== id)),

  // Users
  getUsers: () => Store.get(KEYS.USERS),
  setUsers: (u) => Store.set(KEYS.USERS, u),
  getUser: (email) => Store.getUsers().find(u => u.email === email),
  addUser: (u) => { const arr = Store.getUsers(); arr.push(u); Store.setUsers(arr); },
  updateUser: (email, data) => {
    const arr = Store.getUsers();
    const i = arr.findIndex(u => u.email === email);
    if (i !== -1) { arr[i] = { ...arr[i], ...data }; Store.setUsers(arr); }
  },

  // Cart
  getCart: () => Store.get(KEYS.CART),
  setCart: (c) => Store.set(KEYS.CART, c),
  addToCart: (productId, qty = 1) => {
    const cart = Store.getCart();
    const existing = cart.find(i => i.productId === productId);
    if (existing) { existing.qty += qty; } else { cart.push({ productId, qty }); }
    Store.setCart(cart);
  },
  updateCartQty: (productId, qty) => {
    const cart = Store.getCart();
    const item = cart.find(i => i.productId === productId);
    if (item) { item.qty = qty; }
    Store.setCart(cart.filter(i => i.qty > 0));
  },
  removeFromCart: (productId) => Store.setCart(Store.getCart().filter(i => i.productId !== productId)),
  clearCart: () => Store.setCart([]),
  getCartCount: () => Store.getCart().reduce((s, i) => s + i.qty, 0),

  // Session
  getSession: () => JSON.parse(localStorage.getItem(KEYS.SESSION) || 'null'),
  setSession: (user) => localStorage.setItem(KEYS.SESSION, JSON.stringify(user)),
  clearSession: () => localStorage.removeItem(KEYS.SESSION),
  isLoggedIn: () => !!Store.getSession(),

  // Orders
  getOrders: () => Store.get(KEYS.ORDERS),
  getOrder: (id) => Store.getOrders().find(o => o.id === id),
  setOrders: (o) => Store.set(KEYS.ORDERS, o),
  addOrder: (order) => { const arr = Store.getOrders(); arr.unshift(order); Store.setOrders(arr); },
  updateOrderStatus: (orderId, status) => {
    const arr = Store.getOrders();
    const order = arr.find(o => o.id === orderId);
    if (order) { order.status = status; order.updatedAt = new Date().toISOString(); }
    Store.setOrders(arr);
  },

  // Wishlist
  getWishlist: () => Store.get(KEYS.WISHLIST),
  toggleWishlist: (productId) => {
    const list = Store.getWishlist();
    const idx = list.indexOf(productId);
    if (idx === -1) { list.push(productId); } else { list.splice(idx, 1); }
    Store.set(KEYS.WISHLIST, list);
    return idx === -1; // true = added
  },
  isWishlisted: (productId) => Store.getWishlist().includes(productId),

  // Reviews
  getReviews: () => Store.getObj(KEYS.REVIEWS),
  getProductReviews: (productId) => (Store.getReviews()[productId] || []),
  addReview: (productId, review) => {
    const reviews = Store.getReviews();
    if (!reviews[productId]) reviews[productId] = [];
    reviews[productId].unshift(review);
    Store.set(KEYS.REVIEWS, reviews);
  },

  // Coupons
  getCoupons: () => Store.get(KEYS.COUPONS),
  getCoupon: (code) => Store.getCoupons().find(c => c.code.toUpperCase() === code.toUpperCase() && c.active),
  addCoupon: (c) => { const arr = Store.getCoupons(); arr.push(c); Store.set(KEYS.COUPONS, arr); },
  updateCoupon: (code, data) => {
    const arr = Store.getCoupons();
    const i = arr.findIndex(c => c.code === code);
    if (i !== -1) { arr[i] = { ...arr[i], ...data }; Store.set(KEYS.COUPONS, arr); }
  },
  deleteCoupon: (code) => Store.set(KEYS.COUPONS, Store.getCoupons().filter(c => c.code !== code)),
};

// ── Toast Notifications ────────────────────────────────────────
function toast(message, type = 'default') {
  let container = document.getElementById('toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toast-container';
    document.body.appendChild(container);
  }
  const icons = { success: '✅', error: '❌', info: 'ℹ️', default: '🛒' };
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.innerHTML = `<span>${icons[type] || icons.default}</span><span>${message}</span>`;
  container.appendChild(el);
  setTimeout(() => {
    el.classList.add('removing');
    setTimeout(() => el.remove(), 350);
  }, 3500);
}

// ── Form Validation ────────────────────────────────────────────
function validateField(input, rules) {
  const val = input.value.trim();
  const errEl = document.getElementById(input.id + '-error') ||
                input.nextElementSibling;
  let errMsg = '';
  if (rules.required && !val) errMsg = 'This field is required.';
  else if (rules.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(val)) errMsg = 'Enter a valid email.';
  else if (rules.minLen && val.length < rules.minLen) errMsg = `Minimum ${rules.minLen} characters required.`;
  else if (rules.phone && !/^[6-9]\d{9}$/.test(val)) errMsg = 'Enter valid 10-digit mobile number.';
  else if (rules.pin && !/^\d{6}$/.test(val)) errMsg = 'Enter valid 6-digit PIN code.';

  if (errEl && errEl.classList.contains('form-error')) {
    errEl.textContent = errMsg;
    errEl.classList.toggle('show', !!errMsg);
  }
  input.classList.toggle('error', !!errMsg);
  return !errMsg;
}

// ── Price Formatting ───────────────────────────────────────────
function formatPrice(n) { return '₹' + Number(n).toLocaleString('en-IN'); }

// ── Discount Calculation ───────────────────────────────────────
function calcDiscount(original, current) {
  return Math.round(((original - current) / original) * 100);
}

// ── Star HTML ──────────────────────────────────────────────────
function starsHTML(rating) {
  const full  = Math.floor(rating);
  const half  = rating % 1 >= 0.5 ? 1 : 0;
  const empty = 5 - full - half;
  return '★'.repeat(full) + (half ? '½' : '') + '☆'.repeat(empty);
}

// ── Generate Order ID ──────────────────────────────────────────
function generateOrderId() {
  return 'SH' + Date.now().toString(36).toUpperCase() + Math.random().toString(36).slice(2,5).toUpperCase();
}

// ── Build Header ───────────────────────────────────────────────
function buildHeader() {
  const session = Store.getSession();
  const cartCount = Store.getCartCount();
  const badge = cartCount > 0 ? `<span class="cart-badge">${cartCount}</span>` : '';
  const wishCount = Store.getWishlist().length;
  const wishBadge = wishCount > 0 ? `<span class="cart-badge">${wishCount}</span>` : '';

  // Determine correct path prefix for links
  const isInPages = window.location.pathname.includes('/pages/') || window.location.pathname.includes('/admin/');
  const root = isInPages ? '../' : '';

  const userLinks = session
    ? `<a href="${root}pages/account.html" id="nav-account">👤 ${session.name.split(' ')[0]}</a>
       <a href="#" id="nav-logout">🚪 Logout</a>`
    : `<a href="${root}pages/login.html" id="nav-login">👤 Login</a>`;

  const header = document.getElementById('main-header');
  if (!header) return;

  header.innerHTML = `
    <div class="header-inner">
      <a href="${root}index.html" class="logo-wrap">
        <span class="logo-icon">🍊</span>
        <div>
          <span class="logo-text">SantraHaat</span>
          <span class="logo-sub">Vidarbha's Local Bazaar, Online</span>
        </div>
      </a>
      <form class="search-bar" id="header-search" onsubmit="return handleSearch(event)">
        <input type="text" placeholder="Search oranges, spices, art..." id="search-input" autocomplete="off">
        <button type="submit">🔍</button>
      </form>
      <nav class="header-nav">
        <a href="${root}index.html">🏠 Home</a>
        <a href="${root}pages/shop.html">🛍️ Shop</a>
        <a href="${root}pages/wishlist.html" id="nav-wish" style="position:relative">❤️ Wishlist${wishBadge}</a>
        <a href="${root}pages/cart.html" id="nav-cart" style="position:relative">🛒 Cart${badge}</a>
        ${userLinks}
      </nav>
      <button class="hamburger" onclick="toggleMobileNav()" aria-label="Menu">☰</button>
    </div>
    <nav class="mobile-nav" id="mobile-nav">
      <a href="${root}index.html">🏠 Home</a>
      <a href="${root}pages/shop.html">🛍️ Shop</a>
      <a href="${root}pages/wishlist.html">❤️ Wishlist ${wishBadge}</a>
      <a href="${root}pages/cart.html">🛒 Cart ${badge}</a>
      ${session
        ? `<a href="${root}pages/account.html">👤 My Account</a><a href="#" onclick="logoutUser()">🚪 Logout</a>`
        : `<a href="${root}pages/login.html">👤 Login / Register</a>`}
    </nav>
  `;

  // Logout handler
  const logoutBtn = document.getElementById('nav-logout');
  if (logoutBtn) logoutBtn.addEventListener('click', (e) => { e.preventDefault(); logoutUser(); });

  // Highlight active link
  const links = header.querySelectorAll('.header-nav a, .mobile-nav a');
  const currentPage = window.location.pathname.split('/').pop();
  links.forEach(a => {
    const href = a.getAttribute('href').split('/').pop().split('?')[0];
    if (href === currentPage || (currentPage === '' && href === 'index.html')) {
      a.classList.add('active');
    }
  });
}

function toggleMobileNav() {
  document.getElementById('mobile-nav').classList.toggle('open');
}

function handleSearch(e) {
  e.preventDefault();
  const q = document.getElementById('search-input').value.trim();
  if (!q) return false;
  const isInPages = window.location.pathname.includes('/pages/') || window.location.pathname.includes('/admin/');
  const root = isInPages ? '' : 'pages/';
  window.location.href = root + 'shop.html?q=' + encodeURIComponent(q);
  return false;
}

function logoutUser() {
  const isInPages = window.location.pathname.includes('/pages/') || window.location.pathname.includes('/admin/');
  const root = isInPages ? '../' : '';
  Store.clearSession();
  toast('Logged out successfully.', 'info');
  setTimeout(() => { window.location.href = root + 'index.html'; }, 800);
}

// ── Build Footer ───────────────────────────────────────────────
function buildFooter() {
  const footer = document.getElementById('main-footer');
  if (!footer) return;
  const isInPages = window.location.pathname.includes('/pages/') || window.location.pathname.includes('/admin/');
  const root = isInPages ? '../' : '';

  footer.innerHTML = `
    <div class="footer-grid">
      <div class="footer-brand">
        <div class="logo-text">🍊 SantraHaat</div>
        <p>Vidarbha's first dedicated online bazaar celebrating the rich heritage, handlooms, spices and flavours of Nagpur and the Vidarbha region.</p>
        <div class="footer-social">
          <a href="#" title="Facebook">📘</a>
          <a href="#" title="Instagram">📸</a>
          <a href="#" title="Twitter/X">🐦</a>
          <a href="#" title="YouTube">▶️</a>
        </div>
      </div>
      <div class="footer-col">
        <h4>Quick Links</h4>
        <a href="${root}index.html">Home</a>
        <a href="${root}pages/shop.html">Shop</a>
        <a href="${root}pages/cart.html">Cart</a>
        <a href="${root}pages/account.html">My Account</a>
      </div>
      <div class="footer-col">
        <h4>Categories</h4>
        <a href="${root}pages/shop.html?cat=Oranges">🍊 Oranges</a>
        <a href="${root}pages/shop.html?cat=Spices">🌶️ Spices</a>
        <a href="${root}pages/shop.html?cat=Snacks">🍪 Snacks</a>
        <a href="${root}pages/shop.html?cat=Handloom">🧣 Handloom</a>
        <a href="${root}pages/shop.html?cat=Handicrafts">🎨 Handicrafts</a>
      </div>
      <div class="footer-col">
        <h4>Info</h4>
        <a href="${root}pages/about.html">About Us</a>
        <a href="${root}pages/contact.html">Contact</a>
        <a href="${root}pages/privacy.html">Privacy Policy</a>
        <a href="${root}pages/returns.html">Return Policy</a>
        <a href="${root}admin/login.html">Admin Panel</a>
      </div>
    </div>
    <div class="footer-bottom">
      <p>© 2024 SantraHaat. Made with 🧡 in Nagpur, Vidarbha. | Project: E-Commerce & ERP | RTMNU</p>
    </div>
  `;
}

// ── Product Card HTML ──────────────────────────────────────────
function productCardHTML(p, root = '') {
  const wishlisted = Store.isWishlisted(p.id);
  const off = p.originalPrice ? calcDiscount(p.originalPrice, p.price) : 0;
  const gradients = {
    'Oranges':     'linear-gradient(135deg, #FFF3DC, #FFDDA0)',
    'Spices':      'linear-gradient(135deg, #FFE8D6, #FBBF7A)',
    'Snacks':      'linear-gradient(135deg, #FDEBD0, #F5CBA7)',
    'Handloom':    'linear-gradient(135deg, #E8F5E9, #C8E6C9)',
    'Handicrafts': 'linear-gradient(135deg, #F3E5F5, #CE93D8)',
  };
  const bg = gradients[p.category] || gradients.Oranges;

  return `
    <div class="product-card" id="card-${p.id}" onclick="window.location='${root}pages/product.html?id=${p.id}'">
      <div class="product-img" style="background:${bg}">
        ${off > 0 ? `<span class="product-badge">-${off}%</span>` : ''}
        ${p.isNew ? `<span class="product-badge" style="left:auto;right:0.7rem;background:var(--header)">NEW</span>` : ''}
        <span style="font-size:4rem;user-select:none">${p.emoji}</span>
        <div class="product-actions-overlay">
          <button class="action-btn ${wishlisted ? 'wishlisted' : ''}" onclick="event.stopPropagation();toggleWish('${p.id}',this)" title="Wishlist">
            ${wishlisted ? '❤️' : '🤍'}
          </button>
          <button class="action-btn" onclick="event.stopPropagation();quickAddCart('${p.id}')" title="Add to cart">🛒</button>
        </div>
      </div>
      <div class="product-info">
        <div class="product-category">${p.category}</div>
        <div class="product-name">${p.name}</div>
        <div class="product-stars">${starsHTML(p.rating)} <span>(${p.reviews})</span></div>
        <div class="product-price">
          <span class="price-current">${formatPrice(p.price)}</span>
          ${p.originalPrice ? `<span class="price-original">${formatPrice(p.originalPrice)}</span>` : ''}
          ${off > 0 ? `<span class="price-off">${off}% off</span>` : ''}
        </div>
      </div>
      <div class="product-card-footer">
        <button class="btn btn-primary btn-sm w-full" onclick="event.stopPropagation();quickAddCart('${p.id}')">
          🛒 Add to Cart
        </button>
      </div>
    </div>`;
}

function toggleWish(id, btn) {
  const added = Store.toggleWishlist(id);
  if (btn) {
    btn.textContent = added ? '❤️' : '🤍';
    btn.classList.toggle('wishlisted', added);
  }
  toast(added ? 'Added to wishlist ❤️' : 'Removed from wishlist', added ? 'success' : 'info');
  buildHeader();
}

function quickAddCart(id) {
  const p = Store.getProduct(id);
  if (!p) return;
  if (p.stock === 0) { toast('Out of stock!', 'error'); return; }
  Store.addToCart(id, 1);
  toast(`${p.name} added to cart!`, 'success');
  buildHeader(); // refresh badge
}

// ── Tax Invoice Modal ──────────────────────────────────────────
function openInvoice(orderOrId) {
  const order = typeof orderOrId === 'object' ? orderOrId : Store.getOrder(orderOrId);
  if (!order) { toast('Order details not found.', 'error'); return; }

  const subtotal = order.subtotal || (order.items || []).reduce((s,i) => s + i.price * i.qty, 0);
  const gst = order.gst !== undefined ? order.gst : Math.round(subtotal * 0.05);
  const cgst = (gst / 2).toFixed(2);
  const sgst = (gst / 2).toFixed(2);
  const delivery = order.deliveryCharge !== undefined ? order.deliveryCharge : (order.delivery?.charge || 0);
  const discount = order.discount || 0;
  const total = order.total || (subtotal + gst + delivery - discount);

  let wrap = document.getElementById('invoice-modal-wrap');
  if (!wrap) {
    wrap = document.createElement('div');
    wrap.id = 'invoice-modal-wrap';
    document.body.appendChild(wrap);
  }

  const addr = order.address || {};
  const itemsHTML = (order.items || []).map((item, idx) => {
    const itemTotal = item.price * item.qty;
    return `
      <tr>
        <td style="text-align:center">${idx + 1}</td>
        <td><strong>${item.emoji || '📦'} ${item.name}</strong></td>
        <td style="text-align:center">0805</td>
        <td style="text-align:center">${item.qty}</td>
        <td style="text-align:right">${formatPrice(item.price)}</td>
        <td style="text-align:center">5%</td>
        <td style="text-align:right;font-weight:600">${formatPrice(itemTotal)}</td>
      </tr>`;
  }).join('');

  wrap.innerHTML = `
    <div class="invoice-modal" id="invoice-modal" onclick="if(event.target===this)closeInvoice()">
      <div class="invoice-box" id="invoice-printable">
        <button class="modal-close no-print" onclick="closeInvoice()">✕</button>

        <div class="invoice-header">
          <div class="invoice-brand">
            <span class="icon">🍊</span>
            <div>
              <h2>SantraHaat</h2>
              <p>Vidarbha's Local Bazaar, Online</p>
              <p style="font-size:0.75rem;color:#777">Civil Lines, Nagpur – 440001, Maharashtra<br>GSTIN: 27AABCS1234F1Z9 | CIN: U52100MH2024PTC123456</p>
            </div>
          </div>
          <div class="invoice-title">
            <h3>TAX INVOICE</h3>
            <p><strong>Invoice No:</strong> INV-${order.id}</p>
            <p><strong>Order ID:</strong> #${order.id}</p>
            <p><strong>Date:</strong> ${fmtDate(order.placedAt || new Date().toISOString())}</p>
          </div>
        </div>

        <div class="invoice-meta-grid">
          <div class="invoice-meta-card">
            <h4>Billed & Shipped To:</h4>
            <strong>${addr.name || order.userName || 'Customer'}</strong><br>
            ${addr.addr1 ? addr.addr1 + '<br>' : ''}
            ${addr.addr2 ? addr.addr2 + '<br>' : ''}
            ${addr.city || 'Nagpur'}, ${addr.state || 'Maharashtra'} – ${addr.pin || '440001'}<br>
            📞 Phone: ${addr.phone || '—'}<br>
            📧 Email: ${addr.email || order.userId || '—'}
          </div>
          <div class="invoice-meta-card">
            <h4>Order & Payment Details:</h4>
            <strong>Payment Mode:</strong> ${(order.payMethod || 'COD').toUpperCase()}<br>
            <strong>Payment Status:</strong> <span class="badge badge-green">${order.payMethod === 'cod' ? 'Cash on Delivery' : 'Paid Online'}</span><br>
            <strong>Order Status:</strong> <span class="badge badge-primary">${order.status || 'Placed'}</span><br>
            <strong>Delivery Type:</strong> ${order.delivery?.type === 'express' ? 'Express (1–2 Days)' : 'Standard (5–7 Days)'}<br>
            <strong>Place of Supply:</strong> Maharashtra (State Code: 27)
          </div>
        </div>

        <table class="invoice-table">
          <thead>
            <tr>
              <th style="width:40px;text-align:center">#</th>
              <th>Item Description</th>
              <th style="width:70px;text-align:center">HSN</th>
              <th style="width:50px;text-align:center">Qty</th>
              <th style="width:90px;text-align:right">Rate</th>
              <th style="width:60px;text-align:center">GST</th>
              <th style="width:100px;text-align:right">Amount</th>
            </tr>
          </thead>
          <tbody>
            ${itemsHTML}
          </tbody>
        </table>

        <div class="invoice-summary">
          <table class="invoice-summary-table">
            <tr>
              <td>Taxable Subtotal:</td>
              <td style="text-align:right">${formatPrice(subtotal)}</td>
            </tr>
            <tr>
              <td>CGST (2.5%):</td>
              <td style="text-align:right">₹${cgst}</td>
            </tr>
            <tr>
              <td>SGST (2.5%):</td>
              <td style="text-align:right">₹${sgst}</td>
            </tr>
            <tr>
              <td>Delivery Charges:</td>
              <td style="text-align:right">${delivery > 0 ? formatPrice(delivery) : '<span style="color:#166534">FREE</span>'}</td>
            </tr>
            ${discount > 0 ? `
            <tr style="color:#1F4D3A">
              <td>Coupon Discount${order.coupon ? ' (' + order.coupon + ')' : ''}:</td>
              <td style="text-align:right">- ${formatPrice(discount)}</td>
            </tr>` : ''}
            <tr class="total-row">
              <td>Grand Total:</td>
              <td style="text-align:right">${formatPrice(total)}</td>
            </tr>
          </table>
        </div>

        <div class="invoice-footer-note">
          <p>This is a computer-generated Tax Invoice and does not require a physical signature.</p>
          <p>Thank you for supporting Vidarbha farmers and local artisans! 🍊 Visit again at www.santrahaat.com</p>
        </div>

        <div class="invoice-actions no-print">
          <button class="btn btn-outline" onclick="closeInvoice()">✕ Close</button>
          <button class="btn btn-primary" onclick="window.print()">🖨️ Print Invoice</button>
        </div>
      </div>
    </div>
  `;
}

function closeInvoice() {
  const wrap = document.getElementById('invoice-modal-wrap');
  if (wrap) wrap.innerHTML = '';
}

// ── Cart Totals ────────────────────────────────────────────────
function calcCartTotals(couponCode = null) {
  const cart = Store.getCart();
  let subtotal = 0;
  cart.forEach(item => {
    const p = Store.getProduct(item.productId);
    if (p) subtotal += p.price * item.qty;
  });

  const gst = Math.round(subtotal * 0.05);
  const delivery = subtotal >= 499 ? 0 : 49;
  let discount = 0;
  let couponMsg = '';

  if (couponCode) {
    const coupon = Store.getCoupon(couponCode);
    if (coupon) {
      if (subtotal >= coupon.minOrder) {
        if (coupon.type === 'percent') discount = Math.round(subtotal * coupon.discount / 100);
        else discount = coupon.discount;
        couponMsg = `✅ ${coupon.description}`;
      } else {
        couponMsg = `❌ Minimum order ₹${coupon.minOrder} required.`;
      }
    } else {
      couponMsg = '❌ Invalid coupon code.';
    }
  }

  const grand = subtotal + gst + delivery - discount;
  return { subtotal, gst, delivery, discount, grand, couponMsg };
}

// ── Date/Time Formatter ────────────────────────────────────────
function fmtDate(isoStr) {
  if (!isoStr) return '—';
  return new Date(isoStr).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
}

// ── Scroll to Top Button ───────────────────────────────────────
function initScrollTop() {
  let btn = document.getElementById('scroll-top');
  if (!btn) {
    btn = document.createElement('button');
    btn.id = 'scroll-top';
    btn.innerHTML = '↑';
    btn.title = 'Back to top';
    btn.onclick = () => window.scrollTo({ top: 0, behavior: 'smooth' });
    document.body.appendChild(btn);
  }
  window.addEventListener('scroll', () => {
    btn.classList.toggle('visible', window.scrollY > 400);
  });
}

// ── Page initialization ────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  initStore();
  buildHeader();
  buildFooter();
  initScrollTop();
});